/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"jetCources/ControlTaskPiler/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"jetCources/ControlTaskPiler/test/integration/pages/Worklist",
	"jetCources/ControlTaskPiler/test/integration/pages/Object",
	"jetCources/ControlTaskPiler/test/integration/pages/NotFound",
	"jetCources/ControlTaskPiler/test/integration/pages/Browser",
	"jetCources/ControlTaskPiler/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "jetCources.ControlTaskPiler.view."
	});

	sap.ui.require([
		"jetCources/ControlTaskPiler/test/integration/WorklistJourney",
		"jetCources/ControlTaskPiler/test/integration/ObjectJourney",
		"jetCources/ControlTaskPiler/test/integration/NavigationJourney",
		"jetCources/ControlTaskPiler/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});